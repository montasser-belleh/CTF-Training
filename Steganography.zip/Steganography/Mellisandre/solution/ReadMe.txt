Use the command binwalk -e to extract files from the image
