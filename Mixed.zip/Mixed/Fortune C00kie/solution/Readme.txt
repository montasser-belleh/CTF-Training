extract data from C00kie.png with binwalk
you will find an archive that contains BrokenCookie.jpg
extract data from it with steghide
a password is required 
go back to the jpg , you will find MD5(-1){48bb6e862e54f2a795ffc4e541caed4d}
if you break the hash , you will find "easy"
use it as a password
extract from the jpg , a file Fortune.pyc will appear
uncompile it with uncompyle6
you will see the following


      import matplotlib.pyplot as plt
      fortune=[1,2,3,4,5,4,3,2,1]
      cookie= [5,4,3,2,1,5,4,3,2]
      plt.plot(fortune,cookie,'o')
      plt.text(1,5,'the')
      plt.text(2,4,'flag')
      plt.text(3,3,'is')
      plt.text(4,2,' {')
      plt.text(5,1,'We_')
      plt.text(4,5,'All')
      plt.text(3,4,'_Love_')
      plt.text(2,3,'Biscuits')
      plt.text(1,2,'}')
      plt.show()

so : the flag is {We_All_Love_Biscuits}


