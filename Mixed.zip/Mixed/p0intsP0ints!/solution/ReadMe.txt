extract data from the image p0ints.png 
reverse the python code you will find , use binwalk -e
