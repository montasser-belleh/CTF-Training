import csv
with open('X.csv', 'rb') as x:
    reader = csv.reader(x)
    ab= list(reader)
with open('Y.csv', 'rb') as y:
    reader = csv.reader(y)
    od = list(reader)
flag=''
for i in range(len(ab[0])):
	flag+=chr(int(ab[0][i]))
for i in range(len(od[0])):
	flag+=chr(int(od[0][i]))
print(flag)

	
