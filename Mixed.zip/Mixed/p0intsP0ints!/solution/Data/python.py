import matplotlib.pyplot as plt
import csv
with open('X.csv', 'rb') as x:
    reader = csv.reader(x)
    ab= list(reader)

with open('Y.csv', 'rb') as y:
    reader = csv.reader(y)
    od = list(reader)

plt.plot(ab,od,'o')
plt.show()

