the two lists ab and od , are a lists of lists
ab is a list that contains a single list , so is od , so you have to work on the lists within ab and od , they are ASCII codes so you have to get them back to chr
