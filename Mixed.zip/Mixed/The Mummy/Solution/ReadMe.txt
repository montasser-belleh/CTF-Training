the description and the file Tomb are all hints that you need to use the open source program Tomb 
(https://github.com/dyne/Tomb)
now we shall extract data from the image Phara0h.jpg : tomb exhume Phara0h.jpg
it will require a key/password
going back to the description , we can find it , it is "Amon"
the following will than be shown :
 ____________________________________________________________________
|                                                                     |
| jA0ECQMC7Y9JrhktEOfb0ukB1sCfNRfKTUXAni0RbZPIdLcnrOqAPPxs90DzIqvC    |
| 0asS81op56MR2Sbv15aqPTUh/wysooavW2MJm5sATn+Wt6wpI44rWblTp5okt3U1    |
| HXdgXiXn3+zhgVaTas8Ti48AeotXTaafFxL7Rr+7zuebGOpZYo386BgJgGoBlGyD    |
| G7Sq9vTEvYTAHpkB2FFRF2F4iPoaAbQS4Ct1bNDiVuN9GKenvNr0qY7ukWfI30HX    |
| ZR/msG9QgQo44DOtz8Dcf3POBCbraolluerUYSKXY3z+tpaS7/pQOmrvF4iWi13x    |
| stwvEretHMjPhzwQzYP5NnvjAUf3xb9nhLPfG2bQmqGYzOJbIgCuqPojVIXd2pB2    | 
| PggdQSVyjDDpN1oenEREbuYvcoF/NqPJB/TcG7ExTumsvWbZP/imstQjqdBqwYGL    |
| Vg/lfdR8tZVoOz7TiJ7Hl5BB88Y3iDpcDfqDII2kF+aM8hZaKdnU7v1bBdz4VCck    |
| 6vFH0VXnbMzpwo+OXwjlZf598R/V1cEucZ+zXUH2QkrXK400gl4lVzFrG+tkj70/    |
| hxjEc2vxxrbbmjWp4XYm85q+/FT1a8Dy2NkbNfcpVTIMJbvv0lXoTocqAYm9XRw2    |
| hy9ucSnHwOB2qHi6k951teVkgmFHZYH2ePeZrkBy12utT7uHXW/0S3c9MqyMoIXt    |
| aTluQRUB34FXrDj6TFXFykGSluC+3RzuzhVeIZxXddKKZZm6y3e2paJKg9U8M/h8    |
| NalmWAtC2JWPmmw=                                                    |
| =pMBU                                                               |
| jA0ECQMC7Y9JrhktEOfb0ukB1sCfNRfKTUXAni0RbZPIdLcnrOqAPPxs90DzIqvC    | 
| 0asS81op56MR2Sbv15aqPTUh/wysooavW2MJm5sATn+Wt6wpI44rWblTp5okt3U1    |
| HXdgXiXn3+zhgVaTas8Ti48AeotXTaafFxL7Rr+7zuebGOpZYo386BgJgGoBlGyD    | 
| G7Sq9vTEvYTAHpkB2FFRF2F4iPoaAbQS4Ct1bNDiVuN9GKenvNr0qY7ukWfI30HX    | 
| ZR/msG9QgQo44DOtz8Dcf3POBCbraolluerUYSKXY3z+tpaS7/pQOmrvF4iWi13x    |
| stwvEretHMjPhzwQzYP5NnvjAUf3xb9nhLPfG2bQmqGYzOJbIgCuqPojVIXd2pB2    |
| PggdQSVyjDDpN1oenEREbuYvcoF/NqPJB/TcG7ExTumsvWbZP/imstQjqdBqwYGL    |
| Vg/lfdR8tZVoOz7TiJ7Hl5BB88Y3iDpcDfqDII2kF+aM8hZaKdnU7v1bBdz4VCck    |
| 6vFH0VXnbMzpwo+OXwjlZf598R/V1cEucZ+zXUH2QkrXK400gl4lVzFrG+tkj70/    |
| hxjEc2vxxrbbmjWp4XYm85q+/flag{Mummy_Mia}/FT1a8Dy2NkbNfcpVTIMJbvv    |
| hy9ucSnHwOB2qHi6k951teVkgmFHZYH2ePeZrkBy12utT7uHXW/0S3c9MqyMoIXt    |  
| aTluQRUB34FXrDj6TFXFykGSluC+3RzuzhVeIZxXddKKZZm6y3e2paJKg9U8M/h8    |
| NalmWA                                                              |
|_____________________________________________________________________|

Taking a deep look into it , we will find : flag{Mummy_Mia}

