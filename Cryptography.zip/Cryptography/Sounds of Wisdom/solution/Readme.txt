it is a morse code , use any decoder you want ..
