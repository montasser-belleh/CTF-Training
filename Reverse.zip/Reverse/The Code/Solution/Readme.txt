the image C0de.png is just misleading , the real code is within the image itself , use the command "strings c0de.png" to look at it and than reverse it
