Crypted='{yrzc_trujri!}'
alphabet='abcdefghijklmnopqrstvuwxyz'

def Position(caractere):
    if caractere in alphabet :
        return alphabet.index(caractere)
    else :
        return 69

def CryptCesarCaractere(caractere,pas):
    if Position(caractere)!=69:
        return alphabet[(Position(caractere)+pas)%26]
    else:
        return caractere

def CryptCesarMessage(message,pas):
    crypted=''
    for i in range(len(message)):
        crypted+=CryptCesarCaractere(message[i],pas)
    return crypted

print(CryptCesarMessage(flag,69))


