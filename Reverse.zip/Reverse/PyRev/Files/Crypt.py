encrypted=['77','75','74','5f','54','68','33','5f','68','65','78','5f','69','73','54','68','69','73','21']


def crypt(string):
	return(string.encode("hex"))
