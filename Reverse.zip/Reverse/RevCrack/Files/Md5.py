ToCrack='e6f46dd79d4996616f97cc8bff8e1cac'
import hashlib
def CryptingFunction(flag):
	Sh=hashlib.md5()
	Sh.update(flag)
	return (Sh.hexdigest())




