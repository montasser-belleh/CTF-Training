import codecs
def right(string):
	return(codecs.decode(string,'rot_13').decode("hex"))
print(right('7930755s6730745s4q33'))
