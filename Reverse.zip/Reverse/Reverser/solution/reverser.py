notFlag='7930755s6730745s4q33'

import codecs
def funt(string):
	return(codecs.encode(string.encode("hex"),'rot_13'))

